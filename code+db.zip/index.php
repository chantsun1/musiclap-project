<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Musiclap - Music is your solution!</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div class="cover">
<img src="pic/head.jpg" class="cov"/></div>
<header>
<h1>Musiclap</h1>
<h3>Music is your solution!</h3>
</header>

<div class="nav_h">
</div>

<?php	
include_once('lib/db.inc.php');
	
	$db = ierg4210_DB();
	$q = $db->prepare("SELECT * FROM categories LIMIT 100;");
	$q->execute();
	$cats = $q->fetchAll();

?> 

<nav>
<ul>
Categories:
<li><a href="index.php">All</a></li>
<?php
	for ($i = 0; $i < sizeof($cats); $i++) {
	?><li><a href="index.php?catid=<?php echo $cats[$i]['catid']; ?>"><?php echo $cats[$i]['name']; ?></a></li><?php } echo "\n";?>
    <li><a href = "admin.html">Admin Page</a></li>
</ul>
   
</nav>

<div class="cart">
<h4>Shopping Cart ($80.00)</h4>
<ul>
<li>Dangerous:<br>
<input class="quan" type="number" name="quantity1"> @$50</li>
<li>The Fame Monster:<br> 
<input class="quan" type="number" name="quantity2">@$30</li>
<li><input type="submit" class="quan" name="SubmitCart" value="Check"></li>
</ul>
</div>


<a href="index.php">Home</a> pop<p></p>

<?php
/**
	if(isset($_GET['catid']) && ((int)$_GET['catid'] <= (sizeof($cats)))) {
**/	
		$start = (int)$_GET['catid'];
/**		$end = $start;
	} else {
		$start = 0;
		$end = (int)sizeof($cats) - 1;
	}


	for ($i = $start; $i <= $end; $i++) {
**/		$db = ierg4210_DB();
		$q = $db->prepare("SELECT * FROM products WHERE catid=?");
		$q->execute(array($cats[$start]['catid']));
		$prods = $q->fetchAll();
		
?>
	
 
    <ul class="tableless">	

	  
	 <li>
  	<a href="pop_dangerous.html"><img src=	"http://www.chimesdesign.com/blog/wp-content/uploads/2012/09/michael-jackson-dangerous-album-cover.jpeg" class="thumbn"/></a><br>
    <a href="pop_dangerous.html">Dangerous</a><br>
    Michael Jackson<br>
	$50.00<br>
	<input name="Submit1" type="button" value="Add to Cart">
  	</li>
	
	<?php
      	for ($j =0; $j < sizeof($prods); $j++) {
	  	?>
      <li>
      <a href="details.php?prod=<?php echo $prods[$j]['pid']?>"><img src="pic/lady_gaga_fame_monster.jpg" class="thumbn"/></a><br>
        <a href="details.php?prod=<?php echo $prods[$j]['pid']?>"><?php echo $prods[$j]['name']?></a><br>
		   Michael Jackson<br> 
        HK$<?php echo $prods[$j]['price']?><br>
        <input name="Submit1" type="button" value="Add to Cart">
        </li>
	<?php
	}
	?>
	</ul>

</body>
</html>
